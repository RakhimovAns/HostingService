package main

import (
	"fmt"
	"net/http"
)

func handler(w http.ResponseWriter, r *http.Request) {
	responseText := `Демонстрация работы хостинг сервиса. Загруженный пользователем архив был собран согласно docker-compose.yml внутри него, порты проброшены и доступны в сети по адресу http://hello.ghst.tech/ где hello - название проекта указанное пользователем. Контейнер запущен на домашней хостовой машине. В локальной сети проект запущен на указанных в архиве портам. Nginx адресует все запросы с глобального адреса http://hello.ghst.tech:8080/ на запущенный контейнер с портом 8090`
	fmt.Fprintln(w, responseText)
}

func main() {
	http.HandleFunc("/", handler)
	fmt.Println("Server is running on port 8090...")
	http.ListenAndServe(":8090", nil)
}